# Copy and Extract
Invoke-WebRequest 'https://raw.githubusercontent.com/hiroyay-ms/Deploying-to-Azure-for-CSA/main/Hands-on-Lab/contents/CloudWorkshop.zip' -OutFile 'C:\CloudWorkshop.zip'
Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::ExtractToDirectory('C:\CloudWorkshop.zip','C:\CloudWorkshop')

Copy-Item 'C:\CloudWorkshop\*' -Destination 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA' -Recurse

# Attach ContosoInsurance Database
function Enable-SqlDatabase {
    #Add snap-in
    Add-PSSnapin SqlServerCmdletSnapin* -ErrorAction SilentlyContinue

    $ServerName = 'SQL-SVR'
    $DatabaseName = 'CloudWorkshop'
    $FilePath = 'C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\'
    $MdfFileName = $FilePath + 'CloudWorkshop.mdf'
    $LdfFileName = $FilePath + 'CloudWorkshop_log.ldf'

    $AttachCmd = "CREATE DATABASE [" + $DatabaseName + "] ON (FILENAME = '" + $MdfFileName + "'), (FILENAME = '" + $LdfFileName + "') for ATTACH"

    Invoke-Sqlcmd -ServerInstance $ServerName -Database "master" -Username "SqlUser" -Password "Password.1!!" -Query $AttachCmd
}

Enable-SqlDatabase